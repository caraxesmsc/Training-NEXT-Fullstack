<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="d-grid gap-2" style="margin-bottom: 50px;">
                <a class="btn btn-primary btn-lg" href="/new">New Task</a>
            </div>



            <div class="card bg-warning text-dark">
                <div class="card-header">Tasks</div>
                <div class="card-body">
                    <table class="table table-striped border-warning ">
                        <thead>
                            <tr>
                                <th scope="col">Task</th>
                                <th scope="col">Details</th>
                                <th scope="col">Deadline</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->details); ?></td>
                                <td><?php echo e($value->deadline); ?></td>
                                <td><a href="<?php echo e(url('/update/'.$value->id)); ?>}" class="btn btn-outline-primary">Edit</a></td>
                                <td><a href="<?php echo e(url('/delete/'.$value->id)); ?>}" class="btn btn-outline-danger">Done</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\NEXT-Fullstack\Backend\Lecture14\ToDo_Project\resources\views/home.blade.php ENDPATH**/ ?>