

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark-subtle text-dark">
                <div class="card-header">To DO</div>

                <div class="card-body">
                    <form action="/add" method="post">
                        <?php echo csrf_field(); ?>

                        <p>Task Name</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" name="name" placeholder="TaskName" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <p>Details</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" name="details" placeholder="details" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <p>Study</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" name="deadline" placeholder="due" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-warning">Add</button>
                    </form>

                </div>
            </div>
            <div class="card bg-danger text-light">
            <div class="card-header">Errors</div>
            <div class="card-body">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\NEXT-Fullstack\Backend\Lecture14\ToDo_Project\resources\views/new.blade.php ENDPATH**/ ?>