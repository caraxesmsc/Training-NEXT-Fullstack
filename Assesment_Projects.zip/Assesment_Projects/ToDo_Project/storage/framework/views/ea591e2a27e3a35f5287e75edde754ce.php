

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-primary text-light">
                <div class="card-header">Edit task</div>
                
                <div class="card-body">
                    <form action="<?php echo e(url('/updatedData/'.$toEdit->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <p>Task Name</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" value="<?php echo e($toEdit->name); ?>" name="name" placeholder="Name" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <p>Details</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" value="<?php echo e($toEdit->details); ?>" name="details" placeholder="details" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <p>Study</p>
                        <div class="input-group flex-nowrap">
                            <input type="text" class="form-control" value="<?php echo e($toEdit->deadline); ?>" name="deadline" placeholder="due" aria-label="Username" aria-describedby="addon-wrapping">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-success">Save Changes</button>
                    </form>
                    
                </div>
            </div>
            
            <div class="card bg-danger text-light">
                <div class="card-header">Errors</div>
                <div class="card-body">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\NEXT-Fullstack\Backend\Lecture14\ToDo_Project\resources\views/edit.blade.php ENDPATH**/ ?>