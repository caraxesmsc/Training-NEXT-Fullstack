<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />


</head>

<body class="container">
    <div class="card" style="width: 50%; text-allign:center;">
        <div class="card-header">Credentials</div>
        <div class="card-body">
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>" class="btn btn-primary">Tasks</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-success">Log in</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-warning">Register</a>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        
    </div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\NEXT-Fullstack\Backend\Lecture14\ToDo_Project\resources\views/welcome.blade.php ENDPATH**/ ?>